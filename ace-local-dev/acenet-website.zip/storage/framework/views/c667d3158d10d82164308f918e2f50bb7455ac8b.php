<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
      All Order
      <small>All order are displaying in here</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
      <li class="active">Here</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content container-fluid">

    <!-- /.box-header -->
    <div class="box-body">
        <table class="table table-bordered">
          <tr>
            <th style="width: 10px">#</th>
            <th>Package</th>
            <th>Payment</th>
            <th>Customer Name</th>
            <th>Customer Phone</th>

          </tr>
          <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>1.</td>
          <td><span class="badge bg-red"><?php echo e($order->package_name); ?></span></td>
          <td><span class="badge bg-light-blue"><?php echo e($order->payement_gateway); ?></span></td>
          <td><span class="badge bg-light-blue"><?php echo e($order->billing_name); ?></span></td>
          <td><span class="badge bg-green"><?php echo e($order->billing_phone); ?></span></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
      </div>
      <!-- /.box-body -->

  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\webworks\acenet\acenetlaravel\resources\views/backend/order/index.blade.php ENDPATH**/ ?>
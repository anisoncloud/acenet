<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class="col-md-4 order-md-2 mb-4">

        <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-muted">Your cart</span>

        </h4>
        <?php if(Cart::count()>0): ?>

        <ul class="list-group mb-3">
            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $serviceplan = $item->name;
            ?>
          <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
              <h6 class="my-0"><?php echo e($item->name); ?></h6>
            </div>
            <span class="text-muted"><?php echo e($item->price); ?></span>
          </li>

          <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
              <h6 class="my-0">OTC</h6>
            </div>
            <span class="text-muted"><?php echo e($item->options->delivery); ?></span>
          </li>

          <li class="list-group-item d-flex justify-content-between">
            <span>Total (BDT)</span>
          <strong><?php echo e($item->options->totalPrice); ?></strong>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>

      </div>
      <div class="col-md-8 order-md-1 ls ms">
        <?php if(Session::has('message')): ?>
            <?php echo e(Session::get('message')); ?>

        <?php endif; ?>
        <!--<?php echo e(Session::get('otp_pin')); ?>-->
        <h4 class="mb-3">Billing address</h4>
        <form method="POST" action="https://test.texeltech.com/login.php">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="billing_name">Customer Name</label>
                <input type="text" class="form-control" id="billing_name" name="billing_name"  placeholder="Full Name (as in NID)" value="<?php echo e($customer['billing_name']); ?>" readonly required>
              <?php if ($errors->has('billing_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_name'); ?>
              <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>


          <div class="row">
            <div class="col-md-6 mb-3">
                <label for="billing_phone">Mobile Number </label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="validationTooltipUsernamePrepend">+88</span>
                    </div>
                    <input type="number" class="form-control" id="billing_phone" name="billing_phone" placeholder="Mobile Number" value="<?php echo e($customer['billing_phone']); ?>" minlength="11" pattern = "[0-9]{1,11}" readonly required>
                    <?php if ($errors->has('billing_phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_phone'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>
          </div>
          <div class="mb-3">
            <label for="billing_email">Email</label>
          <input type="email" class="form-control" id="billing_email" name="billing_email" placeholder="Email" value="<?php echo e($customer['billing_email']); ?>" readonly required>
            <?php if ($errors->has('billing_email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_email'); ?>
              <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </span>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>

          <div class="row">
            <div class="col-md-8 mb-3">
                <label for="billing_nid">National ID</label>
                <input type="text" class="form-control" id="billing_nid" name="billing_nid" placeholder="NID" value="<?php echo e($customer['billing_nid']); ?>" readonly required>
                <?php if ($errors->has('billing_nid')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_nid'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="col-md-4 mb-3">
                <label for="billing_gender">Gender</label>
                <input type="text" class="form-control" id="billing_gender" name="billing_gender" placeholder="Gener" value="<?php echo e($customer['billing_gender']); ?>" readonly required>

                <?php if ($errors->has('billing_gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_gender'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 mb-3">
                <label for="billing_apartment">Apartment</label>
                <input type="text" class="form-control" id="billing_apartment" name="billing_apartment" placeholder="Apartment" value="<?php echo e($customer['billing_apartment']); ?>" readonly required>
                <?php if ($errors->has('billing_apartment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_apartment'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
			<div class="col-md-6 mb-3">
                <label for="billing_house">House</label>
                <input type="text" class="form-control" id="billing_house" name="billing_house" placeholder="House" value="<?php echo e($customer['billing_house']); ?>" readonly required>
                <?php if ($errors->has('billing_house')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_house'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
          </div>
		  <div class="row">
            <div class="col-md-6 mb-3">
                <label for="billing_road">Road</label>
                <input type="text" class="form-control" id="billing_road" name="billing_road" placeholder="Road" value="<?php echo e($customer['billing_road']); ?>" readonly required>
                <?php if ($errors->has('billing_road')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_road'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="col-md-6 mb-3">
                <label for="billing_block">Block</label>
                <input type="text" class="form-control" id="billing_block" name="billing_block" placeholder="Block" value="<?php echo e($customer['billing_block']); ?>" readonly required>
                <?php if ($errors->has('billing_block')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_block'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
          </div>

          <div class="row">
		  <div class="col-md-6 mb-3">
              <label for="billing_area">Area</label>
              <input type="text" class="form-control" id="billing_area" name="billing_area" placeholder="Block" value="<?php echo e($customer['billing_area']); ?>" readonly required>
              <?php if ($errors->has('billing_area')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_area'); ?>
              <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </span>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
			<div class="col-md-6 mb-3">
                <label for="billing_city">City</label>
                <input type="text" class="form-control" id="billing_city" name="billing_city" placeholder="City" value="<?php echo e($customer['billing_city']); ?>" readonly required>
                <?php if ($errors->has('billing_city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_city'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
          </div>
		  <div class="row">
            <div class="col-md-6 mb-3">
                <label for="billing_pcode">Post Code</label>
                <input type="text" class="form-control" id="billing_pcode" name="billing_pcode" placeholder="Post Code" value="<?php echo e($customer['billing_pcode']); ?>" readonly required>
                <?php if ($errors->has('billing_pcode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_pcode'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="col-md-6 mb-3">
                <label for="billing_splan">Service Plan</label>
                <input type="text" class="form-control" id="billing_splan" name="billing_splan" placeholder="Service Plan" value="<?php echo e($serviceplan); ?>" readonly required>
                <?php if ($errors->has('billing_splan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_splan'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
          </div>
		   <div class="row">
            <div class="col-md-6 mb-3">
              <label for="billing_zone">Zone</label>
              <input type="text" class="form-control" id="billing_zone" name="billing_zone" placeholder="Zone" value="<?php echo e($customer['billing_zone']); ?>" readonly required>
              <?php if ($errors->has('billing_zone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_zone'); ?>
              <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </span>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="col-md-6 mb-3">
                <label for="billing_cdate">Connectivity Date</label>
                <input type='date' class="form-control" id='billing_cdate'  name="billing_cdate" placeholder="yyyy/mm/dd" value="<?php echo e($customer['billing_cdate']); ?>" readonly required />
                <?php if ($errors->has('billing_cdate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_cdate'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
          </div>
		  <div class="mb-3">
              <label for="billing_note">Note</label>
                <textarea  class="form-control" id="billing_note" name="billing_note"  placeholder="Note" readonly required><?php echo e($customer['billing_note']); ?> </textarea>
              <?php if ($errors->has('billing_note')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('billing_note'); ?>
              <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

        
          <style>
              #map {
              height: 300px;
            }
          </style>
        <div id="map" class="map"></div>

        <script>
            //var map, infoWindow;

            var geocoder = new google.maps.Geocoder();
          function initMap() {
              if (navigator.geolocation) {
                  navigator.geolocation.getCurrentPosition(function(position) {
                  var myLatlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                  console.log(`Lat: ${position.coords.latitude} Lng: ${position.coords.longitude}`) ;
                  var mapOptions = {
                      zoom: 18,
                      center: myLatlng,
                      mapTypeId: google.maps.MapTypeId.ROADMAP
                  };
                  var map = new google.maps.Map(document.getElementById('map'), mapOptions);
                  var marker = new google.maps.Marker();
                  marker.setPosition(myLatlng);
                  marker.setMap(map);

                  /*geocoder.geocode({'latLng': myLatlng}, function(results, status) {
                  if(status == google.maps.GeocoderStatus.OK) { if(results[0]) {
                      $('#address_current').text(results[0].formatted_address);
                  }
                  else {
                      alert('No results found');
                  }

              }
              else {
                  var error = { 'ZERO_RESULTS': 'We Could Not Find Your Address' }
                  $('#address_new').html('' + error[status] + ''); } }); */
          }, function() {
                  alert("Your Site is not Using https. So, browser does not support Geolocation.");
              });
          }
      }
      </script>
        <script defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB-RqC_GAn3jagvHwceAYEKkCK4u5mNKyA&callback=initMap"></script>
        

          <hr class="mb-4">
          <a href="javascript:history.back()" class="btn btn-primary">Back</a>
          <button class="btn btn-primary btn-lg " type="submit">Continue to checkout</button>


        </form>
      </div>
    </div>
</div>
<?php $__env->startSection('javascripts'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\webworks\acenet\acenetlaravel\resources\views/front-end/checkoutpre.blade.php ENDPATH**/ ?>
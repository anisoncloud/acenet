<?php $__env->startSection('content'); ?>
<div class="jumbotron text-center">
    <h1 class="display-3">Thank You!</h1>

    <p class="lead"><strong>Please check your email</strong> for further instructions on how to complete your account setup.</p>
    <hr>
    <p>
        <?php if(Session::has('success_message')): ?>
    <div class="alert alert-success">
        <?php echo e(Session::get('success_message')); ?>

    </div>
<?php endif; ?>
      Having trouble? <a href="">Contact us</a>
    </p>
    <p class="lead">
    <a class="btn btn-primary btn-sm" href="<?php echo e(url('/')); ?>" role="button">Continue to homepage</a>
    </p>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\webworks\acenet\acenetlaravel\resources\views/front-end/thankyou.blade.php ENDPATH**/ ?>
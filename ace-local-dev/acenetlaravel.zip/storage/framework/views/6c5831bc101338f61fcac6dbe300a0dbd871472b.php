<?php $__env->startComponent('mail::message'); ?>

<h1>ACE Net Contact Email</h1>

<strong>Name: </strong> <?php echo e($data['name']); ?><br/>
<strong>Email: </strong> <?php echo e($data['email']); ?><br/>
<strong>Phone: </strong> <?php echo e($data['mobile']); ?><br/>
<strong>Address: </strong> <?php echo e($data['address']); ?><br/>
<strong>Zone: </strong> <?php echo e($data['zone']); ?><br/>
<strong>Package: </strong> <?php echo e($data['package']); ?><br/>
<strong>Message: </strong> <?php echo e($data['message']); ?>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\webworks\acenet\acenetlaravel\resources\views/emails/contact/contact-form.blade.php ENDPATH**/ ?>